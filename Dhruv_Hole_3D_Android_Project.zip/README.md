# Dhruv Hole 3D — Android APK build project

This project wraps the Hole Rush 3D browser game in a simple Android WebView app.

## Build an APK from your phone using GitHub Actions

1. Create a new GitHub repository and upload the **contents** of this ZIP (not the ZIP itself).
2. Open the repository's **Actions** tab.
3. Select **Build Dhruv Hole 3D APK**.
4. Tap **Run workflow** if it is not started automatically.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run and download the artifact named `Dhruv-Hole-3D-debug-apk`.
7. Extract the downloaded artifact ZIP; install `app-debug.apk` on your Android phone.

## Notes

- This is a debug APK for testing, not a Play Store release build.
- The game loads Three.js from a CDN, so the phone needs an internet connection while playing.
- This project is an original prototype and is not affiliated with the Hole All in One game.
